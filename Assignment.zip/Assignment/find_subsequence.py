"""
    Context:
    Time series are an ubiquitous type of data, appearing in many applications.
    For instance, conventional vehicles are equipped with a variety of sensors, which collect enormous amounts of data
    every second. Conversely, we might have anonymized health care records of a large number of patients,
    spanning multiple years, and want to identify temporal patterns to gain insight about how diseases develop over time.

    To make use of this large pool of data in our pipeline, we need to identify interesting subsequences.
    The task below, is an abstraction of this, with a list of integers representing the sensor data and the sum
    is the metric to evaluate if a subsequence is interesting.

    Inputs:
    Input text files can be found in data folder
    
    Author:
    Sidharth Das
"""

## ----------------------------------------------------------------------------------------------------------------------------------------------------------------
"""
    Base Task: Given a list of integers, the function below finds consecutive,
    non-empty subsequence with the highest _sum_.(largest contigious sum)
"""
def max_sum(arr):
    # Variable to keep track of maximum sum of traversed elements at each step
    maximum_sum = -1

    # Variable to compare sum of traversed elements at each step
    current_sum = 0

    # Loop through each element of the sequence
    for index in range(0, len(arr)):
        current_sum = current_sum + arr[index]

        # Compare current sum at each step with maximum value of it so far 
        if (maximum_sum < current_sum):
            maximum_sum = current_sum

        # If current sum is less than zero start afresh from that step
        if (current_sum < 0):
            current_sum = 0

    return maximum_sum

## ----------------------------------------------------------------------------------------------------------------------------------------------------------------
"""
    Extended Task: Function below finds largest contagious sum, give that the input is extended
    by a second parameter `n` that restricts the maximum length of the subsequence to n
"""
def max_sum_restricted(arr, n):
    # Variable to keep track of maximum sum of traversed elements at each step
    maximum_sum = -1

    # Variable to shift start point of a subsequence
    start = 0

    # Check if restricted length is less than size of array
    while (n < len(arr)):
        # Variable to compare sum of traversed elements at each step
        current_sum = 0

        # Loop through each element of the sequence
        for index in range(start, n):
            current_sum = current_sum + arr[index]

            # Compare current sum at each step with maximum value of it so far 
            if (maximum_sum < current_sum):
                maximum_sum = current_sum

            # If current sum is less than zero start afresh from that step
            if (current_sum < 0):
                current_sum = 0
                
        # increment start and end points of sequence
        n = n + 1
        start = start + 1

    return maximum_sum

## ----------------------------------------------------------------------------------------------------------------------------------------------------------------

"""
    Extended task:
    The input is extended by a third parameter which changes how the METRIC is calculated.
    Instead of the _sum_ of the values we want to find the highest _sum_ of the absolute
    values of the differences of neighboring pairs. As an example, for the input [3 -5 1 2 -1 4 -3 1 -2],
    the absolute differences would be: `8 6 1 3 5 7 4 3` and therefore the output should be `16`
    for `n = 4` as `-1 4 -3 1` result in the absolute differences of `5 7 4` which adds up to `16`.
"""

def metric(arr, n):
    new_arr = []
    for index in range(0, len(arr)-1):
        x = abs(arr[index] - arr[index+1])
        new_arr.append(x)

    maximum_sum = max_sum_restricted(new_arr, n-1)

    return maximum_sum

## ----------------------------------------------------------------------------------------------------------------------------------------------------------------
## Input 1

# Read input file
with open('data/input_1.txt', 'r') as f:
    data = f.read()

array = [int(i) for i in data.split()]

# Find largest contagious sum
maximum_sum = max_sum(array)

# Find largest contagious sum subject to restriction in length of sequence
restriction = 2
restricted_maximum_sum = max_sum_restricted(array, restriction)

# Find Metric
restriction = 4
metric_sum = metric(array, restriction)

print('find_subsequence.py data/input_1.txt')
print('---------------------------------------------------------')
print('Largest contagious sum is')
print(maximum_sum)
print('Highest sum while maximum Length of subsequence is restricted to n = 2, is')
print(restricted_maximum_sum)
print('Metric sum with n = 4, is')
print(metric_sum)
print('')

## Input 2-------------------------------------------------------------------------------------------------------

# Read input file
with open('data/input_2.txt', 'r') as f:
    data = f.read()

array = [int(i) for i in data.split()]

# Find largest contagious sum
maximum_sum = max_sum(array)

# Find largest contagious sum subject to restriction in length of sequence
restriction = 2
restricted_maximum_sum = max_sum_restricted(array, restriction)

# Find Metric
restriction = 4
metric_sum = metric(array, restriction)

print('find_subsequence.py data/input_2.txt')
print('---------------------------------------------------------')
print('Largest contagious sum is')
print(maximum_sum)
print('Highest sum while maximum Length of subsequence is restricted to n = 2, is')
print(restricted_maximum_sum)
print('Metric sum with n = 4, is')
print(metric_sum)
print('')

## Input 3-------------------------------------------------------------------------------------------------------

# Read input file
with open('data/input_3.txt', 'r') as f:
    data = f.read()

array = [int(i) for i in data.split()]

# Find largest contagious sum
maximum_sum = max_sum(array)

# Find largest contagious sum subject to restriction in length of sequence
restriction = 2
restricted_maximum_sum = max_sum_restricted(array, restriction)

# Find Metric
restriction = 4
metric_sum = metric(array, restriction)

print('find_subsequence.py data/input_3.txt')
print('---------------------------------------------------------')
print('Largest contagious sum is')
print(maximum_sum)
print('Highest sum while maximum Length of subsequence is restricted to n = 2, is')
print(restricted_maximum_sum)
print('Metric sum with n = 4, is')
print(metric_sum)
print('')
